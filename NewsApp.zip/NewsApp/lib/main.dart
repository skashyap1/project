import 'package:flutter/material.dart';
import 'package:newsapp/homePage.dart';

void main() {
  runApp(const MaterialApp(
    home: HomePage(),
  ));
}
