import 'package:flutter/material.dart';
import 'package:ted_app/shared/navBar.dart';
import 'package:ted_app/shared/body.dart';

class Home extends StatelessWidget {
  const Home({super.key});

  @override
  Widget build(BuildContext context) {
    return const Scaffold(
      appBar: navBar(),
      body: body(),
    );
  }
}