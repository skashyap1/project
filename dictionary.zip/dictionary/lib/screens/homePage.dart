import 'package:dict/service/dictclient.dart';
import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  DictClient dCLient = DictClient();
  TextEditingController tc = TextEditingController();
  String meaning = "null";
  // String m = null;
  // called when the page is first built
  // @override
  // void initState() {
  //   print("I was called first");
  //   // // TODO: implement initState
  //   // super.initState();
  // }

  _callAPI(q) async {
    // print("The API is called with the following word $q");
    meaning = await dCLient.searchForward(query: q);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
        child: Scaffold(
      appBar: AppBar(
        title: const Text("DICTIONARY"),
        centerTitle: true,
      ),
      body: SizedBox(
        // color: Colors.teal,
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        child: Padding(
          padding: const EdgeInsets.all(15.0),
          child: Column(
            children: [
              TextField(
                controller: tc,
                decoration: InputDecoration(
                    border: const OutlineInputBorder(
                        borderRadius: BorderRadius.all(Radius.circular(50))),
                    suffixIcon: IconButton(
                        onPressed: () {}, icon: const Icon(Icons.clear)),
                    // label: const Text("DICT"),
                    hintText: "Enter a Word Here"),
                // style: ,
                keyboardType: TextInputType.text,
                onChanged: (string) {
                  // print(textfield.text); //controller--> text
                  print("This is the text from the textfield $string");
                },
                onEditingComplete: () {
                  // print(
                  //     // "this is the final submission from the textfield ${txtfld.text}");
                },
              ),
              OutlinedButton(
                  style: ButtonStyle(
                      foregroundColor: MaterialStateProperty.all(Colors.black),
                      backgroundColor: MaterialStateProperty.all(Colors.amber),
                      overlayColor: MaterialStateProperty.all(Colors.green)),
                  onPressed: () {
                    _callAPI(tc.text);
                    tc.clear();
                    setState(() {});
                  },
                  child: const Text("SEARCH")),
              Container(
                padding: const EdgeInsets.all(10),
                color: Colors.amber,
                width: MediaQuery.of(context).size.width,
                // height: MediaQuery.of(context).size.height * 0.15,
                child: Center(
                  child: Text(
                    meaning,
                    style: const TextStyle(fontSize: 25),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    ));
  }
}
